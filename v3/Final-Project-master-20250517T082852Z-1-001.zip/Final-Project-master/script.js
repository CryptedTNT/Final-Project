
//lightmode / darkmode
    const contentBg = document.getElementById('content_box');
    const bodyBg = document.getElementById('body');
    const sideBarBg = document.getElementById('body');
    const offCanBg = document.getElementById('offcanvas_bg');
function setLightMode() {

    // Set body to light
    bodyBg.classList.remove('bg-dark', 'text-light');
    bodyBg.classList.add('bg-light', 'text-dark');

    // Set content to light (if needed)
    contentBg.classList.remove('bg-dark', 'text-light');
    contentBg.classList.add('bg-light', 'text-dark');

    //set sidebar icon to light
    sideBarBg.classList.remove('bg-dark', 'text-light');
    sideBarBg.classList.add('bg-light', 'text-dark');

    //set offcanvas body icon to light
    offCanBg.classList.remove('bg-dark', 'text-light');
    offCanBg.classList.add('bg-light', 'text-dark');
}

function setDarkMode() {
    

    // Set body to dark
    bodyBg.classList.remove('bg-light', 'text-dark');
    bodyBg.classList.add('bg-dark', 'text-light');

    // Set content to dark
    contentBg.classList.remove('bg-light', 'text-dark');
    contentBg.classList.add('bg-dark', 'text-light');

    //set sidebar icon to dark
    sideBarBg.classList.remove('bg-light', 'text-dark');
    sideBarBg.classList.add('bg-dark', 'text-light');

    //set offcanvas body icon to dark
    offCanBg.classList.remove('bg-light', 'text-dark');
    offCanBg.classList.add('bg-dark', 'text-light');
}
